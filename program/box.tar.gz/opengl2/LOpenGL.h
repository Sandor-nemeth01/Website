#ifndef LOPENGL_H_INCLUDED
#define LOPENGL_H_INCLUDED

#include <GL/freeglut.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <iostream>

#endif // LOPENGL_H_INCLUDED
